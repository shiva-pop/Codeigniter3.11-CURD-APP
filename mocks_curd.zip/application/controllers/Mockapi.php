<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mockapi extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		
	}

	public function curPostwrite()
	{

		$data = json_decode(file_get_contents('php://input'), true);

		$insert_data = $this->db->insert_batch('user', $data);

		if($insert_data){

			$response = array('message'=>'sucess','code'=>1);

		}
		else{
			$response = array('message'=>'fail','code'=>-1);
		}

		echo json_encode($response);
		
	}

	public function curPostRequest()
    {
        /* Endpoint */
        $url = 'http://localhost/mocks_curd/index.php/mockapi/curPostwrite';
   
        /* eCurl */
        $curl = curl_init($url);
   
        /* Data */
        $data = file_get_contents('MOCK_DATA.json');
   
        /* Set JSON data to POST */
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
            
        /* Define content type */
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
            
        /* Return json */
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            
        /* make request */
        $result = curl_exec($curl);
             
        /* close curl */
        curl_close($curl);
    }

}
