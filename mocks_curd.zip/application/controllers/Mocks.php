<?php
class Mocks extends CI_Controller{
	function __construct(){
		parent::__construct();
		$this->load->model('Mock_model');
	}
	function index(){
		$this->load->view('listEmp');
	}
	function show(){
		$data=$this->Mock_model->employeeList();

		echo json_encode($data);
	}
	function save(){
		$data = $this->input->post();
//echo json_encode($data);exit;
		$data=$this->Mock_model->saveEmp();
		echo json_encode($data);
	}
	function update(){
		$data=$this->Mock_model->updateEmp();
		echo json_encode($data);
	}

	function getuser(){
		$data=$this->Mock_model->getuser();
		echo json_encode($data);
	}

	function delete(){
		$data=$this->Mock_model->deleteEmp();
		echo json_encode($data);
	}

}