<?php
class Mock_model extends CI_Model{

	function employeeList(){
		$hasil=$this->db->get('user');
		return $hasil->result();
	}
	function saveEmp(){
		$geners_arr = $this->input->post_get('geners');

		if(is_array($geners_arr)){
			$geners_str = implode('|',$geners_arr);
		}
		else{
			$geners_str = '';
		}

		$ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';

		$data = array(				
				'first_name' 	=> $this->input->post_get('fname'), 
				'last_name'     => $this->input->post_get('lname'), 
				'email' 	    => $this->input->post_get('email'), 
				'gender' 		=> $this->input->post_get('gender'), 
				'genres' 		=> $geners_str,
				'ip_address'    =>  $ipaddress,
			);

			
		$result=$this->db->insert('user',$data);
		return $result;
	}
	function updateEmp(){
		$id=$this->input->post_get('id');
		$firstname=$this->input->post_get('fname');
		$lastname=$this->input->post_get('lname');
		$email=$this->input->post_get('email');
		$gender=$this->input->post_get('gender');
		$this->db->set('first_name', $firstname);
		$this->db->set('last_name', $lastname);
		$this->db->set('email', $email);
		$this->db->set('gender', $gender);
		$this->db->where('id', $id);
		$result=$this->db->update('user');
		return $result;	
	}
	function deleteEmp(){
		$id=$this->input->post_get('id');
		//return $id; exit;
		$this->db->where('id', $id);
		$result=$this->db->delete('user');
		return $result;
	}
	
	function getuser(){
		$id=$this->input->post_get('id');
		//return $id; exit;
		$this->db->select('*');
        $this->db->from('user');
        $this->db->where('id',$id);
        $query = $this->db->get();
        $data = $query->row();
		return json_encode($data);
	}
}