<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>CURD APPLICATION</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/css/bootstrap.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/css/jquery.dataTables.css' ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/css/dataTables.bootstrap4.css' ?>">
	<style>
		.dataTables_wrapper .dataTables_paginate .paginate_button {
			box-sizing: border-box;
			display: inline-block;
			min-width: 1.5em;
			padding: 1px;
			margin-left: 2px;
			text-align: center;
			text-decoration: none !important;
			cursor: pointer;
			color: #333 !important;
			border: 1px solid transparent;
			border-radius: 2px;
		}
	</style>
</head>

<body>
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="col-md-12">
					<br>

					<br>
					<h1>CRUD Operations in CodeIgniter 3.1.1<br>
						<div class="float-right"><a href="javascript:void(0);" class="btn btn-primary" data-toggle="modal" data-target="#addEmpModal"><span class="fa fa-plus"></span> Add New</a></div><br>
					</h1>
				</div>
				<table class="table table-striped" id="employeeListing">
					<thead>
						<tr>
							<th>First Name</th>
							<th>Last Name</th>
							<th>Email</th>
							<th>Gender</th>
							<th>Ip Address</th>
							<th style="text-align: right;">Actions</th>
						</tr>
					</thead>
					<tbody id="listRecords">
					</tbody>
				</table>
			</div>
		</div>

	</div>
	<form id="saveEmpForm" method="post">
		<div class="modal fade" id="addEmpModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Add New Employee</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<div class="form-group row">
							<label class="col-md-2 col-form-label">First Name*</label>
							<div class="col-md-10">
								<input type="text" name="fname" id="fname" class="form-control" placeholder="John" required>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-md-2 col-form-label">Last Name*</label>
							<div class="col-md-10">
								<input type="text" name="lname" id="lname" class="form-control" placeholder="Smith" required>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-md-2 col-form-label">Email*</label>
							<div class="col-md-10">
								<input type="email" name="email" id="email" class="form-control" placeholder="johnsmith@test.com" required>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-md-2 col-form-label">Gender*</label>
							<div class="col-md-10">
								<input class="form-check-input" type="radio" name="gender" id="gender" value="Male">
								<label class="form-check-label">Male</label>
								<input class="form-check-input" type="radio" name="gender" id="gender" value="Female">
								<label class="form-check-label">Female</label>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-md-2 col-form-label">Genres*</label>
							<div class="col-md-10">
								<input class="form-check-input" type="checkbox" name="geners[]" id="geners1" value="Comedy">
								<label class="form-check-label" for="inlineRadio1">Comedy</label>
								<input class="form-check-input" type="checkbox" name="geners[]" id="geners2" value="Horror">
								<label class="form-check-label" for="inlineRadio1">Horror</label>
								<input class="form-check-input" type="checkbox" name="geners[]" id="geners2" value="Mystery">
								<label class="form-check-label" for="inlineRadio1">Mystery</label>
								<input class="form-check-input" type="checkbox" name="geners[]" id="geners2" value="Sci-Fi">
								<label class="form-check-label" for="inlineRadio1">Sci-Fi</label>
								<input class="form-check-input" type="checkbox" name="geners[]" id="geners4" value="Thriller">
								<label class="form-check-label" for="inlineRadio1">Thriller</label>
								<input class="form-check-input" type="checkbox" name="geners[]" id="geners5" value="Adventure">
								<label class="form-check-label" for="inlineRadio1">Adventure</label>
								<input class="form-check-input" type="checkbox" name="geners[]" id="geners6" value="Romance">
								<label class="form-check-label" for="inlineRadio1">Romance</label>
								<input class="form-check-input" type="checkbox" name="geners[]" id="geners7" value="Drama">
								<label class="form-check-label" for="inlineRadio1">Drama</label>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</div>
			</div>
		</div>
	</form>


	<div class="modal fade" id="addmocksuess" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-body">
					<div class="alert alert-success" role="alert">
						This is a success alert—check it out!
					</div>
					<div class="form-group row">
						<h2>Record Added Successfully</h2>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="modal" id="updatedmocksuess" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-body" id="updatedmocksuess">
					<div class="alert alert-success" role="alert">
						Record Updated Successfully
					</div>

				</div>
			</div>
		</div>
	</div>

	<div class="modal" id="deletedmocksuess" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-body" id="updatedmocksuess">
					<div class="alert alert-success" role="alert">
						Record Deleted Successfully
					</div>

				</div>
			</div>
		</div>
	</div>


	<form id="editEmpForm" method="post">
		<div class="modal fade" id="editEmpModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="editModalLabel">Edit Employee</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<div class="form-group row">
							<label class="col-md-2 col-form-label">Frst Name*</label>
							<div class="col-md-10">
								<input type="text" name="efname" id="efname" class="form-control" placeholder="First Name" required>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-md-2 col-form-label">Last Name*</label>
							<div class="col-md-10">
								<input type="text" name="elname" id="elname" class="form-control" placeholder="Last Name" required>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-md-2 col-form-label">Email*</label>
							<div class="col-md-10">
								<input type="text" name="eemail" id="eemail" class="form-control" placeholder="example@gmail.com" required>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-md-2 col-form-label">Gender*</label>
							<div class="col-md-10">
								<input class="form-check-input" type="radio" name="gender" id="mgender" value="Male">
								<label class="form-check-label">Male</label>
								<input class="form-check-input" type="radio" name="gender" id="fgender" value="Female">
								<label class="form-check-label">Female</label>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<input type="hidden" name="euserid" id="euserid" class="form-control">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Update</button>
					</div>
				</div>
			</div>
		</div>
	</form>
	<form id="deleteEmpForm" method="post">
		<div class="modal fade" id="deleteEmpModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="deleteModalLabel">Delete User</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<strong>Are you sure to delete this record?</strong>
					</div>
					<div class="modal-footer">
						<input type="hidden" name="deleteMockId" id="deleteMockId" class="form-control">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
						<button type="submit" class="btn btn-primary">Yes</button>
					</div>
				</div>
			</div>
		</div>
	</form>
	<script type="text/javascript" src="<?php echo base_url() . 'assets/js/jquery-3.2.1.js' ?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'assets/js/bootstrap.js' ?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'assets/js/jquery.dataTables.js' ?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'assets/js/dataTables.bootstrap4.js' ?>"></script>
	<script type="text/javascript" src="<?php echo base_url() . 'assets/js/crud_operation.js' ?>"></script>
</body>

</html>