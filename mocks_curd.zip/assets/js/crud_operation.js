$(document).ready(function () {
	listEmployee();
	var table = $('#employeeListing').dataTable({
		"bPaginate": true,
		"bInfo": true,
		"bFilter": true,
		"bLengthChange": true,
		"order": [[1, "desc"]],
		"pageLength": 20
	});
	// list all employee in datatable
	function listEmployee() {
		//alert('hi');
		$.ajax({
			type: 'ajax',
			url: 'mocks/show',
			async: false,
			dataType: 'json',
			success: function (data) {
				var html = '';
				var i;
				//console.log(data);

				for (i = 0; i < data.length; i++) {
					//console.log(data[i].email);
					html += '<tr id="' + data[i].id + '">' +
						'<td>' + data[i].first_name + '</td>' +
						'<td>' + data[i].last_name + '</td>' +
						'<td>' + data[i].email + '</td>' +
						'<td>' + data[i].gender + '</td>' +
						'<td>' + data[i].ip_address + '</td>' +
						'<td style="text-align:right;">' +
						'<a href="javascript:void(0);" class="btn btn-info btn-sm editRecord" data-id="' + data[i].id + '" data-name="' + data[i].name + '" data-age="' + data[i].age + '" data-skills="' + data[i].skills + '" data-designation="' + data[i].designation + '" data-address="' + data[i].address + '">Edit</a>' + ' ' +
						'<a href="javascript:void(0);" class="btn btn-danger btn-sm deleteRecord" data-id="' + data[i].id + '">Delete</a>' +
						'</td>' +
						'</tr>';
				}
				$('#listRecords').html(html);
			}

		});
	}
	// save new employee record
	$('#saveEmpForm').submit('click', function () {
		var ufname = $('#fname').val();
		var ulname = $('#lname').val();
		var ugender = $('#gender').val();
		var uemail = $('#email').val();
		var ugeners = [];
		$(':checkbox:checked').each(function (i) {
			ugeners[i] = $(this).val();
		});

		$.ajax({
			type: "GET",
			url: "mocks/save",
			dataType: "JSON",
			data: { fname: ufname, lname: ulname, email: uemail, gender: ugender, geners: ugeners },
			success: function (data) {
				$('#fname').val("");
				$('#lname').val("");
				$('#email').val("");
				$('#gender').val("");
				$('#addEmpModal').modal('hide');
				$('#addmocksuess').modal('show');
				//setTimeout($('#addmocksuess').modal('hide'), 4000);
				listEmployee();
			}
		});
		return false;
	});
	// show edit modal form with emp data
	$('#listRecords').on('click', '.editRecord', function () {
		$('#editEmpModal').modal('show');

		$("#empId").val($(this).data('id'));

		var userid = $(this).data('id');
		$.ajax({
			type: "GET",
			url: "mocks/getuser",
			dataType: "JSON",
			data: { id: userid },
			success: function (data) {
				
				//alert(data);
				var reslt = JSON.parse(data);
				//alert(reslt.first_name);
				$('#euserid').val(reslt.id);
				$('#efname').val(reslt.first_name);
				$('#elname').val(reslt.last_name);
				$('#eemail').val(reslt.email);
				if(reslt.gender == 'Male'){
					$('#mgender').attr('checked', true);
				}
				else{
					$('#fgender').attr('checked', true);
				}
				//$('#efname').val(reslt.gender);
			}
		});
	});
	
	// save edit record
	$('#editEmpForm').on('submit', function () {
		var userid = $('#euserid').val();
		var first_name = $('#efname').val();
		var last_name = $('#elname').val();
		var user_email = $('#eemail').val();
		var user_gender = $("input[name=gender]").val();
		//alert(user_gender);
		$.ajax({
			type: "GET",
			url: "mocks/update",
			dataType: "JSON",
			data: { id: userid, fname: first_name, lname: last_name, email: user_email, gender: user_gender},
			success: function (data) {
				$("#euserid").val("");
				$("#efname").val("");
				$('#elname').val("");
				$("#eemail").val("");
				$("input[name=gender]").val("");
				$('#editEmpModal').modal('hide');
				$('#updatedmocksuess').modal('show');
				$("#updatedmocksuess").children().delay(5000).fadeOut(800);
				
				listEmployee();
			}
		});
		return false;
	});
	// show delete form
	$('#listRecords').on('click', '.deleteRecord', function () {
		var mockid = $(this).data('id');
		//alert(mockid);            
		$('#deleteEmpModal').modal('show');
		$('#deleteMockId').val(mockid);
	});
	// delete emp record
	$('#deleteEmpForm').on('submit', function () {
		var empId = $('#deleteMockId').val();
		//alert(empId);
		$.ajax({
			type: "GET",
			url: "mocks/delete",
			dataType: "JSON",
			data: { id: empId },
			success: function (data) {
				//alert(data);
				$("#" + empId).remove();
				$('#deleteMockId').val("");
				$('#deleteEmpModal').modal('hide');
				$('#deletedmocksuess').modal('show');
				$("#deletedmocksuess").children().delay(5000).fadeOut(800);
				//listEmployee();
			}
		});
		return false;
	});
});